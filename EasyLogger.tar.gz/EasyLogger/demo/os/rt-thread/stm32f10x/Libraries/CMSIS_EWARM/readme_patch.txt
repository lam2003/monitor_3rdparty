No CMSIS patch is included in this version.
